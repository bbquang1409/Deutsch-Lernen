// ═══ Deutsch-Lernen · Apps Script ═══
// Kein Gemini mehr. Dashboard (alle Daten) nur mit verifiziertem Google-Token des Lehrers.
const SHEET_ID = "1io5GhrPYyezdLEeFNcNZAQLFmBcAqJ1jIGd4e8C0sDQ";
const TEACHER_EMAIL = "baoquang@gmail.com";
const GOOGLE_CLIENT_ID = "565949426173-cg9jat7abv9jbk2hktuak1sud8pc11do.apps.googleusercontent.com";

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// Schutz vor Formel-Injection im Sheet (=, +, -, @ am Anfang)
function safe_(v) {
  v = String(v == null ? "" : v).slice(0, 200);
  return /^[=+\-@]/.test(v) ? "'" + v : v;
}

// Prüft ein Google-ID-Token bei Google; gibt die verifizierte E-Mail zurück oder null.
function verifiedEmail_(token) {
  if (!token) return null;
  try {
    var res = UrlFetchApp.fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(token), { muteHttpExceptions: true });
    if (res.getResponseCode() !== 200) return null;
    var t = JSON.parse(res.getContentText());
    if (t.aud !== GOOGLE_CLIENT_ID) return null;
    if (String(t.email_verified) !== "true") return null;
    if (Number(t.exp) * 1000 < Date.now()) return null;
    return t.email || null;
  } catch (err) { return null; }
}

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var score = Number(data.score), total = Number(data.total);
    if (!isFinite(score) || !isFinite(total) || total <= 0 || score < 0 || score > total) {
      return json_({ status: "error", msg: "invalid data" });
    }
    var sheet = SpreadsheetApp.openById(SHEET_ID).getActiveSheet();
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["Thời gian","Tên học sinh","Email","File bài tập","Bộ câu hỏi","Điểm","Tổng câu","Phần trăm"]);
    }
    sheet.appendRow([new Date(), safe_(data.name), safe_(data.email), safe_(data.file), safe_(data.set), score, total, Math.round(score / total * 100) + "%"]);
    return json_({ status: "ok" });
  } catch (err) {
    return json_({ status: "error", msg: err.toString() });
  }
}

function doGet(e) {
  try {
    var action = e.parameter.action || "";
    var sheet = SpreadsheetApp.openById(SHEET_ID).getActiveSheet();
    var rows = sheet.getDataRange().getValues();
    var headers = rows[0] || [];
    var allData = rows.slice(1).map(function (row) {
      var obj = {}; headers.forEach(function (h, i) { obj[h] = row[i]; }); return obj;
    });

    // Lehrer: alle Daten — nur mit gültigem Token
    if (action === "all") {
      var who = verifiedEmail_(e.parameter.token);
      if (who !== TEACHER_EMAIL) {
        return json_({ status: "error", code: "auth", msg: "Kein Zugriff. Bitte als Lehrer anmelden." });
      }
      return json_({ status: "ok", data: allData, isTeacher: true });
    }

    // Schüler: eigene Ergebnisse (per E-Mail, wie bisher)
    var email = e.parameter.email || "";
    var mine = email ? allData.filter(function (r) { return r["Email"] === email; }) : [];
    return json_({ status: "ok", data: mine, isTeacher: false });
  } catch (err) {
    return json_({ status: "error", msg: err.toString() });
  }
}
