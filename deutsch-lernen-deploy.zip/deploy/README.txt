DEUTSCH-LERNEN – Launch-Reihenfolge
===================================

1) apps-script/Code.gs
   Apps Script oeffnen -> alten Code ersetzen -> Deploy > Manage deployments > Edit > New version > Deploy
   (gleiches Deployment behalten, damit die /exec-URL gleich bleibt)
   Gemini-Keys in Google AI Studio LOESCHEN (beide).

2) gitrepo-root/  -> in D:\GitHub\Deutsch-Lernen\ kopieren (ueberschreiben):
   index.html, manifest.json, service-worker.js, icon-maskable-512.png,
   dashboard.html, my-results.html, wortschatz.html
   (alte index.html vorher ggf. als index-old.html sichern)

3) replace-existing-file/Arbeit-und-Beruf-A1.html
   -> die gleichnamige Datei im Ordner A1A2/Wortschatz/... ersetzen.
   Pruefen: Zeile  var _DL_HUB = "../../../index.html";  (Tiefe anpassen)

4) git add -A && git commit && git push
   Danach die App 1-2x oeffnen (neuer Service Worker uebernimmt).

Test: Hub oeffnen -> anmelden -> Grammatik/Wortschatz ohne neues Login ->
      Uebung machen -> als Lehrer im Dashboard anmelden -> Eintrag sichtbar.
