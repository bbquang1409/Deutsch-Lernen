KlassenLive UI/UX Update 2026-11-21
Copy teacher.html, student.html, exercise-demo.html and klassenlive-bridge.js to your existing KlassenLive GitHub folder. Keep your existing config.js. No SQL changes.
Teacher monitor: newest room selected by default; selected room remains visible after finish.
Student: centered brand, compact responsive layout. Demo: compact answer field, hides technical UUID and redundant timer.
